package com.example.brilliantsacrifice

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val initial = listOf(
    "♜","♞","♝","♛","♚","♝","♞","♜",
    "♟","♟","♟","♟","♟","♟","♟","♟",
    "","","","","","","","",
    "","","","","","","","",
    "","","","","","","","",
    "","","","","","","","",
    "♙","♙","♙","♙","♙","♙","♙","♙",
    "♖","♘","♗","♕","♔","♗","♘","♖"
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { BrilliantApp() }
    }
}

@Composable
fun BrilliantApp() {
    var board by remember { mutableStateOf(initial) }
    var selected by remember { mutableIntStateOf(-1) }
    var brilliantMode by remember { mutableStateOf(true) }
    var status by remember { mutableStateOf("White to move · Select a piece") }
    var moves by remember { mutableStateOf(listOf<String>()) }

    MaterialTheme(colorScheme = darkColorScheme(
        primary = Color(0xFFE0B45B),
        background = Color(0xFF101827),
        surface = Color(0xFF1D2939)
    )) {
        Column(
            modifier = Modifier.fillMaxSize().background(Color(0xFF101827)).padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text("BRILLIANT SACRIFICE", color = Color(0xFFE0B45B), fontSize = 23.sp, fontWeight = FontWeight.Black)
            Text("CHESS ENGINE", color = Color.White, fontSize = 13.sp, letterSpacing = 4.sp)
            Spacer(Modifier.height(18.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Brilliant Mode", color = Color.White, fontWeight = FontWeight.Bold)
                Spacer(Modifier.width(10.dp))
                Switch(checked = brilliantMode, onCheckedChange = { brilliantMode = it })
            }
            Spacer(Modifier.height(12.dp))
            Text("Demo board · engine integration not yet connected", color = Color(0xFFB8C4D6), fontSize = 12.sp)
            Spacer(Modifier.height(10.dp))
            Column(Modifier.fillMaxWidth().aspectRatio(1f)) {
                for (r in 0..7) {
                    Row(Modifier.weight(1f)) {
                        for (c in 0..7) {
                            val idx = r * 8 + c
                            val light = (r + c) % 2 == 0
                            val square = if (light) Color(0xFFF0D9B5) else Color(0xFFB58863)
                            Box(
                                Modifier.weight(1f).fillMaxHeight()
                                    .background(if (selected == idx) Color(0xFFE6D34D) else square)
                                    .clickable {
                                        if (selected == -1) {
                                            if (board[idx].isNotEmpty()) selected = idx
                                        } else {
                                            if (idx != selected && board[idx].isEmpty()) {
                                                status = "Board preview only — legal move validation is not connected yet."
                                            }
                                            selected = -1
                                        }
                                    },
                                contentAlignment = Alignment.Center
                            ) {
                                Text(board[idx], fontSize = 32.sp, color = if (board[idx] in listOf("♙","♘","♗","♖","♕","♔")) Color.White else Color(0xFF171717))
                            }
                        }
                    }
                }
            }
            Spacer(Modifier.height(16.dp))
            Text(status, color = Color.White, fontSize = 14.sp)
            Spacer(Modifier.height(12.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = {
                    board = initial; selected = -1; moves = emptyList(); status = "New game · White to move"
                }) { Text("New game") }
                Button(onClick = {
                    status = if (brilliantMode)
                        "Brilliant Mode is selected. Connect a Stockfish build to enable engine play."
                    else "Standard engine mode selected. Connect a Stockfish build to enable engine play."
                }) { Text("Engine move") }
            }
            Spacer(Modifier.height(12.dp))
            Text("Sacrifice-first engine concept", color = Color(0xFFE0B45B), fontWeight = FontWeight.Bold)
            Text(
                "The finished engine will search for sound sacrifices and tactical shots. This starter is a visual prototype, not a playable chess engine yet.",
                color = Color(0xFFB8C4D6), fontSize = 12.sp
            )
        }
    }
}
