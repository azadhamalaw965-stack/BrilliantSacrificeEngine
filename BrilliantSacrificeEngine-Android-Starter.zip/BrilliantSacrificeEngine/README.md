# Brilliant Sacrifice Engine — Android starter

This is an Android Studio **visual prototype**, not a finished chess engine or installable APK.

## Open it
1. Install Android Studio on a computer.
2. Choose **Open** and select this project folder.
3. Let Gradle sync, then run the `app` configuration on an Android device or emulator.

## Current status
- Dark themed app shell and chessboard preview.
- Brilliant Mode switch and New Game / Engine Move controls.
- The board is currently visual only: legal move validation, move history, check/checkmate, and engine play are not implemented.

## What is needed for the real engine
A complete version needs:
- A legal chess rules library for move generation and game-state validation.
- A compatible Stockfish Android engine binary (built for the device ABI).
- UCI process integration to send positions and receive engine moves.
- A sacrifice-scoring layer that evaluates candidate moves and prefers **sound** sacrifices, rather than sacrificing material blindly.

Stockfish is GPL-licensed. If it is bundled or distributed, include the applicable license and corresponding source-code compliance materials. Do not download random engine APKs or binaries from untrusted sites.
